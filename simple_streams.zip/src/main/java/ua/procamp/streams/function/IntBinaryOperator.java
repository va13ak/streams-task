package ua.procamp.streams.function;

public interface IntBinaryOperator {
    int apply(int left, int right);
}
