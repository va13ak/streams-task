package ua.procamp.streams.function;

public interface IntConsumer {
    void accept(int value);
}
