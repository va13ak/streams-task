package ua.procamp.streams.function;

public interface IntPredicate {
    boolean test(int value);
}
