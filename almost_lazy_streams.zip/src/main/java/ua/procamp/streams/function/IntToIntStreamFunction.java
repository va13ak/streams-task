package ua.procamp.streams.function;

import ua.procamp.streams.stream.IntStream;

public interface IntToIntStreamFunction {
     IntStream applyAsIntStream(int value);
}
