package ua.procamp.streams.function;

public interface IntUnaryOperator {
    int apply(int operand);
}
