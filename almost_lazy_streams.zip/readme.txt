almost "lazy calculation" implementation
some moments in flatMap()